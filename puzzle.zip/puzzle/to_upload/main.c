#define _GNU_SOURCE
#include <fcntl.h> 
#include <stdio.h>
#include <unistd.h>


__asm__(
    ".intel_syntax noprefix\n"
    
    ".global gadget_pop_rdi_ret\n"
    "gadget_pop_rdi_ret:\n"
    "   pop rdi\n"
    "   ret\n"
    
    ".global gadget_pop_rax_ret\n"
    "gadget_pop_rax_ret:\n"
    "   pop rax\n"
    "   ret\n"

    ".global gadget_pop_rsi_ret\n"
    "gadget_pop_rsi_ret:\n"
    "   pop rsi\n"
    "   ret\n"
    
    ".global gadget_pop_rdx_ret\n"
    "gadget_pop_rdx_ret:\n"
    "   pop rdx\n"
    "   ret\n"
    
    ".global gadget_mov_rdi_rax_ret\n"
    "gadget_mov_rdi_rax_ret:\n"
    "   mov QWORD PTR [rdi], rax\n"
    "   ret\n"
    
    ".global gadget_syscall_ret\n"
    "gadget_syscall_ret:\n"
    "   syscall\n"
    "   ret\n"

    ".att_syntax prefix\n"
);

char useful_stuff[16];

void vuln() {
    char buf[64];
    printf("Welcome now let's make it harder\n");
    printf("It's like a puzzle you must link the pieces together to reveal the hidden path !!!\n");
    printf("before i quit i've left something behind that might help you => %p\n",useful_stuff);
    read(0,buf,256);
    printf("GL ;)\n");
}

int main() {
    vuln();
    return 0;
}
