#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void print_stack(void *address, int range) {
    printf("\nStack Layout (around %p):\n", address);
    printf("Address\t\tValue\t\tASCII\n");
    printf("----------------------------------------\n");
    unsigned int *ptr = (unsigned int *)address;
    for (int i = -range/2; i < range/2; i++) {
        printf("%p\t0x%08x\t", ptr+i, *(ptr+i));        
        unsigned char *bytes = (unsigned char *)(ptr+i);
        for (int j = 0; j < 4; j++) {
            if (bytes[j] >= 32 && bytes[j] <= 126) {
                putchar(bytes[j]);
            } else {
                putchar('.');
            }
        }
        putchar('\n');
    }
}

void admin_panel() {
    if (secret == 0x1337) {
        printf("\nCongratulations! You have admin access now :) \n");
        printf("Here's your flag: CTF{}\n");
    } else {
        printf("\nsecret is 0x%x, but needs to be 0x1337\n", secret);
    }
}

void vuln() {
    char buffer[32];
    int secret = 0x1336;
    printf("=== 32-bit Buffer Overflow Challenge ===\n");
    printf("Objective: Overflow the buffer to change secret to 0x1337\n\n");
    
    printf("[Memory Addresses]\n");
    printf("buffer @ %p\n", buffer);
    printf("secret @ %p (value: 0x%x)\n", &secret, secret);
    
    print_stack(buffer, 16);
    
    printf("\nEnter your payload: ");
    fflush(stdout);
    
    gets(buffer);
    
    printf("\n[After Overflow]\n");
    printf("secret = 0x%x\n", secret);
    
    print_stack(buffer, 16);
    
    admin_panel();
}

int main(int argc, char *argv[]) {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    vuln();

    return 0;
}
