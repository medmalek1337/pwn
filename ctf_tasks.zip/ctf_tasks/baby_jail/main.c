#include <stdio.h>
#include <unistd.h>

void vuln() {
    char buffer[27];
    printf("Can you reveal my secret !!! just escape \n");
    printf("GL :)\n");
    fflush(stdout);
    read(0, buffer, 27); 
    printf("Your stuck !!!! next time :< \n");
    void (*ret)() = (void(*)())buffer;
    ret();
}

int main() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    vuln();
    return 0;
}