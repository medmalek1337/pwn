#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h> 

int fd = 0;
char flag[0x50];

void win() {
    fd = open("flag.txt", O_RDONLY); 
    if (fd < 0) {
        puts("Failed to open flag.txt");
        exit(1);
    }
    read(fd, flag, 0x50);
    puts(flag);
    close(fd);
    return;
}
void setup();
void vuln();

int main() {
    vuln();
    return 0;
}

void setup() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}
char *gets(char *s); 
void vuln() {
    setup();
    long long cookie = 0xdeadbeefcafebabe;
    char buffer[16];
    printf("people call me random but there's a method to my madness a hidden pattern behind the chaos\n");
    printf("This is just a little sample of my randomness %p\n", main);
    printf("Input =>");
    fflush(stdout);
    gets(buffer);
    if (cookie != 0xdeadbeefcafebabe){
        printf("Stack smashing detected !!!!");
        exit(1);
    }
}